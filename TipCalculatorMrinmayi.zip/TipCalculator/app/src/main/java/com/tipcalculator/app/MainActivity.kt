package com.tipcalculator.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import java.text.NumberFormat

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TipCalculatorScreen()
        }
    }
}

@Composable
fun TipCalculatorScreen() {
    var billAmount by remember { mutableStateOf("") }
    val tipPercent = listOf(0.15, 0.18, 0.20)

    // State variables to hold the calculated tip and total bill amount
    var calculatedTip by remember { mutableStateOf(99.99) }
    var totalBill by remember { mutableStateOf(99.99) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // EditText on top, centered horizontally
        OutlinedTextField(
            value = billAmount,
            onValueChange = { billAmount = it },
            label = { Text("Enter Bill Amount") },
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.CenterHorizontally)  // Centered horizontally
        )

        // Row of buttons, centered horizontally
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 32.dp)
                .align(Alignment.CenterHorizontally)  // Centered horizontally
        ) {
            tipPercent.forEach { percent ->
                Button(
                    onClick = {
                        val enteredAmount = billAmount.trim()
                        if (enteredAmount.isNotEmpty()) {
                            val parsedAmount = enteredAmount.toDoubleOrNull()
                            if (parsedAmount != null) {
                                // Calculate tip and total bill directly within onClick
                                calculatedTip = parsedAmount * percent
                                totalBill = calculatedTip + parsedAmount
                            } else {
                                // Handle invalid input (optional)
                            }
                        }
                    }
                ) {
                    Text(text = "${(percent * 100).toInt()}%")
                }
            }
        }

        // TextView below the buttons (corrected part)
        if (billAmount.isNotEmpty()) {
            // Display the calculated tip and total bill
            ShowTip(calculatedTip, totalBill)
        }
    }
}

@Composable
fun ShowTip(calculatedTip: Double, totalBill: Double) {
    Text(
        text = "Tip: ${formatCurrency(calculatedTip)}, Total Bill: ${formatCurrency(totalBill)}",
        textAlign = TextAlign.Center,
        style = MaterialTheme.typography.bodyLarge
    )
}

fun formatCurrency(value: Double): String {
    val formatter = NumberFormat.getCurrencyInstance()
    return formatter.format(value)
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    TipCalculatorScreen()
}
